# 密码管理器服务端 (Password Manager Server)

## 快速安装与运行
直接在服务器上执行：
```bash
bash install.sh
```

## 服务端功能
- 服务端全权加解密 (AES-256-GCM + PBKDF2)
- 简美现代化 Web 管理控制台 (http://<ip>:8000)
- 用户与管理员 Token 鉴权 (默认账号: jason / admin@1234)
- 一键导出/导入私钥与密码记录
- 一键更换主私钥并重新加密所有记录
- 支持从网页端直接下载安卓客户端 APK
